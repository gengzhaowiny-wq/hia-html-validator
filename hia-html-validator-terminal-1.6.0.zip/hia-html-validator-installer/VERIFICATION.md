# Package verification — 1.6.0

- Installer shell syntax checked.
- Local npm tarball created with an explicit file allowlist: 26 package files, including README.md, AGENTS.md and RULES.md; no lesson HTML, screenshots, prior reports, node_modules or machine-specific runtime paths.
- Installer exercised in a new user-style prefix whose path contains spaces, without changing the real user prefix, PATH startup files or source lessons.
- Dependencies resolved from that clean installation with `NODE_PATH` unset. Node.js 24.19.0 and pinned Playwright 1.62.1 were used on macOS.
- `setup` successfully invoked the installed Playwright CLI. A matching Chromium cache already existed; a first-time Chromium download was not simulated.
- `doctor` confirmed Node, package dependency and browser-file availability. Actual browser tests also completed.
- **293 regression cases passed:** 7 SVG, 86 formula-style, 24 models, 59 visual-review, 32 page-pair, 50 complementary, 35 command-line/general-HTML cases.
- CLI coverage includes plain HTML without lesson markup, real horizontal overflow, clipping warnings, native radical review, paths with spaces, partial configuration, batch status propagation, duplicate basenames, recursive discovery, safe output targets, offline resource reporting and source-only coverage disclosure.
- An installed-command run on the revised Chapter 8 lesson inspected all **40 displayed pages / 144 reveal states** and reported **0 errors / 158 review-warning records**, matching the prior audit. That smoke test used `--no-screenshots`; image generation was separately exercised in the general-HTML tests.
- No accessibility suite, automatic content fixing or automatic visual approval was added. Symbol-review warnings remain explicit.

Linux/WSL installation instructions are supplied, but those operating systems were not runtime-tested in this session. Browser/OS dependencies and font availability can change rendering; run `doctor`, `setup` and a real validation on the destination machine.

The package is intentionally local/private and is not published to an npm registry. Dependencies and Chromium are downloaded during installation/setup; they are not bundled into this small archive. `SHA256SUMS` checks the supplied npm tarball for accidental corruption.

## Documentation refresh

README.md is now the human-facing installation/use guide, with a copyable LLM request. AGENTS.md is the standard agent-discovery file and gives an authority-aware installation, validation and reporting workflow. The previous detailed README is preserved as RULES.md. These documents are included in both the installer ZIP and npm tarball; the tarball checksum is refreshed. This refresh changes documentation and the package file allowlist, not validator JavaScript, rule settings or lesson files. The full runtime test results above remain applicable.

Refresh verification: all 18 JavaScript files matched the previously tested release; five documentation files matched between source and installer folders; 20 local documentation links resolved. A fresh-prefix installation of the repacked tarball passed command help, doctor and all 35 CLI/general-HTML regression cases. The tarball inventory and checksum were checked before rebuilding the ZIP.

## Project rename to hia-html-validator

The GitHub repository, npm package identity, primary terminal command, CLI diagnostics and installation examples now use `hia-html-validator`. `html-validate-b35` and `b35-validate` remain executable aliases. Rule IDs, configuration keys, report naming and validation behaviour are unchanged. The installer tarball and ZIP were rebuilt under the new name, with refreshed checksums.

All **294 regression cases passed** after the rename, including a new package-identity/command-alias test and the existing browser tests. A separate fresh-prefix installation passed help for all three commands, doctor and all 36 CLI/browser regression cases with NODE_PATH unset. The optional fsevents install script was blocked by npm's default protections; no protection was disabled, and the checks still passed. The historical Chapter 8 smoke test above was not repeated for this naming-only change. Linux/WSL and a first-time browser download remain unverified.
