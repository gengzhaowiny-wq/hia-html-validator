# HTML validator — Terminal installer

Start with [README.md](README.md) for manual installation or [AGENTS.md](AGENTS.md) for an LLM assistant's installation/validation workflow.

1. Install Node.js **20+ with npm** if it is not already available: [nodejs.org](https://nodejs.org/).
2. Open Terminal in this extracted folder and run:

```bash
bash install.sh
export PATH="$HOME/.local/bin:$PATH"
hia-html-validator doctor
```

Then validate any local HTML file:

```bash
hia-html-validator "/path/to/your-file.html"
```

Use the complete B35 lesson checks automatically for compatible `.slide` decks. Other HTML gets current-document layout, resource, SVG and maths checks; it does not require lesson navigation. General mode does not traverse arbitrary hidden/interactive pages or certify HTML syntax, mathematical correctness or visual approval. It runs trusted input scripts in a temporary browser; it is not an OS security sandbox.

Your input is not edited. Open `your-file-b35-report/report.md`, `report.json`, or `visual-review.html`. Warnings include review guidance for LLMs. No accessibility audit or automatic fixes are added.

```bash
hia-html-validator file.html --out ./results
hia-html-validator ./lessons --recursive --out ./results
hia-html-validator file.html --profile html --viewport 1280x800
hia-html-validator file.html --fail-on-warning
hia-html-validator --help
```

Exit codes: **0** no automated errors (review/warnings may remain), **1** findings, **2** invalid/incomplete. `--static-only` performs source preflight only, not rendered validation.

`install.sh` uses the user-owned `$HOME/.local` prefix, downloads the required dependencies/Chromium, and prints a PATH instruction without editing startup files. A custom prefix is supported: `bash install.sh --prefix /path/to/prefix`. Linux system libraries may need `hia-html-validator setup --with-deps`. The installation is not a standalone binary: Node.js/npm and installation-time network access are required.

See **CLI_GUIDE.md** for configuration, limits, safety, troubleshooting and removal. The tarball contains the complete pipeline, editable rule modules and tests, but no lesson HTML, prior reports or screenshots. It has not been published to an npm registry.
